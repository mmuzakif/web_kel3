CREATE DATABASE IF NOT EXISTS db_undangan
 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_undangan;
CREATE TABLE acara (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 mempelai VARCHAR(100) NOT NULL,
 tanggal DATE NOT NULL,
 waktu TIME NOT NULL,
 lokasi VARCHAR(150) NOT NULL,
 alamat TEXT NOT NULL
) ENGINE=InnoDB;
CREATE TABLE rsvp (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 acara_id INT UNSIGNED NOT NULL,
 nama VARCHAR(100) NOT NULL,
 kehadiran ENUM('hadir','tidak') NOT NULL,
 jumlah TINYINT UNSIGNED NOT NULL DEFAULT 0,
 ucapan VARCHAR(500) NOT NULL DEFAULT '',
 dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (acara_id) REFERENCES acara(id)
) ENGINE=InnoDB;
INSERT INTO acara (mempelai,tanggal,waktu,lokasi,alamat)
VALUES ('Alya & Rizky','2026-12-20','10:00:00',
 'Gedung Melati','Jl. Melati No. 10, Bandung');
