# Undangan pernikahan PHP + MySQL

Proyek latihan lokal untuk PPT. Data pasangan dan alamat merupakan contoh fiktif.

## Menjalankan dari awal
1. Pasang Laragon dari https://laragon.org/download sesuai ketentuan lisensinya.
2. Pastikan Apache, PHP 8.x dan MySQL tersedia. Klik Start All.
3. Tambahkan phpMyAdmin melalui Menu > Tools > Quick add > phpMyAdmin jika belum ada. Nama/menu dapat berbeda antarversi.
4. Salin folder undangan ke C:\laragon\www\undangan (sesuaikan folder instalasi).
5. Buka http://localhost/phpmyadmin dan masuk dengan akun MySQL lokal Anda.
6. Pada tab Import, pilih database.sql lalu klik Go/Kirim. Lakukan SATU KALI pada database baru.
   SQL membuat db_undangan, tabel acara dan rsvp, lalu satu acara contoh.
   Jika membuat db_undangan lewat UI dahulu, gunakan utf8mb4_unicode_ci.
7. Edit host, port, db, user dan pass pada config.php sesuai MySQL lokal.
   root dengan password kosong hanya contoh konfigurasi latihan lokal, tidak universal.
8. Buka http://localhost/undangan/ melalui browser (jangan klik file PHP).
9. Isi RSVP, kirim, kemudian buka db_undangan > rsvp > Browse di phpMyAdmin.
10. Ubah detail acara lewat acara > Browse > Edit. Muat ulang halaman.

## Urutan belajar file
database.sql, config.php, index.php, simpan.php, style.css.
PPT berisi potongan kode, sedangkan file di folder ini berisi kode lengkap.

## Uji manual
- Hadir dengan jumlah 2: satu baris baru dan pesan sukses.
- Tidak hadir: jumlah tersimpan 0.
- Nama kosong atau jumlah hadir 6: permintaan ditolak (browser/server).
- Ucapan <script>alert(1)</script>: tampil sebagai teks, tidak dieksekusi.
- Refresh setelah kirim: tidak mengirim ulang POST.
- GET simpan.php langsung: status 405.
- CSRF tidak valid: status 403.
- Nama/ucapan Unicode: didukung utf8mb4, batas server dihitung dalam byte.
- Pengiriman RSVP baru berulang masih boleh. Belum ada identitas tamu unik.

## SQL latihan (tab SQL di phpMyAdmin)
SELECT * FROM rsvp ORDER BY id DESC;
SELECT COALESCE(SUM(jumlah),0) AS total_orang FROM rsvp WHERE kehadiran='hadir';
UPDATE acara SET lokasi='Gedung Kenanga' WHERE id=1;
-- Ganti 123 dengan ID BARIS UJI yang sudah diperiksa, lalu hapus hanya data uji:
DELETE FROM rsvp WHERE id=123;

## Backup dan pemulihan
Pilih db_undangan > Export > Quick > SQL > Go. Simpan juga folder proyek.
Untuk mencoba pemulihan, buat db_undangan_latihan lalu pilih database tersebut > Import.
Pastikan SQL cadangan tidak mengandung USE db_undangan atau CREATE DATABASE yang mengalihkan target.
Jika perlu, ubah nama target pada salinan SQL dahulu. Jangan menimpa database utama.

## Batas proyek
Latihan lokal, belum siap publik. Pengelolaan data dilakukan melalui phpMyAdmin.
Belum ada login admin web, undangan personal, moderasi, atau pencegahan spam.
Sebelum hosting: akun DB khusus berizin minimum, password kuat, HTTPS, proteksi konfigurasi,
moderasi ucapan, pembatasan permintaan, dan backup. Jangan unggah file SQL/README ke web publik.
Jangan membuka phpMyAdmin untuk publik tanpa kontrol akses yang sesuai.
