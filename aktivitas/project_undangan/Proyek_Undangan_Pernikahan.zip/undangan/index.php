<?php
require __DIR__ . '/config.php';
$acara = $pdo->query('SELECT * FROM acara WHERE id = 1')->fetch();
if (!$acara) { http_response_code(404); exit('Acara belum tersedia. Import database.sql.'); }
$stmt = $pdo->prepare("SELECT nama, ucapan FROM rsvp WHERE acara_id = ? AND ucapan <> '' ORDER BY id DESC LIMIT 20");
$stmt->execute([$acara['id']]);
$ucapan = $stmt->fetchAll();
$flash = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);
?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Undangan <?= e($acara['mempelai']) ?></title>
<link rel="stylesheet" href="style.css"></head><body>
<main>
<header><p>UNDANGAN PERNIKAHAN</p>
<h1><?= e($acara['mempelai']) ?></h1>
<p>Dengan penuh kebahagiaan, kami mengundang Anda untuk hadir.</p>
<h2><?= e(date('d-m-Y', strtotime($acara['tanggal']))) ?></h2>
<p>Pukul <?= e(substr($acara['waktu'],0,5)) ?> WIB</p>
<h3><?= e($acara['lokasi']) ?></h3><p><?= e($acara['alamat']) ?></p>
<a href="#rsvp">Konfirmasi kehadiran</a></header>
<section id="rsvp"><h2>RSVP & ucapan</h2>
<?php if ($flash): ?><p role="status"><?= e($flash) ?></p><?php endif; ?>
<form method="post" action="simpan.php">
<input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
<label>Nama<input name="nama" required maxlength="100" autocomplete="name"></label>
<label>Kehadiran<select name="kehadiran" required>
<option value="hadir">Hadir</option><option value="tidak">Tidak hadir</option>
</select></label>
<label>Jumlah orang (1–5 jika hadir)<input name="jumlah" type="number" min="0" max="5" value="1" required></label>
<label>Ucapan<textarea name="ucapan" maxlength="500" rows="4"></textarea></label>
<p>Nama dan ucapan tampil di halaman ini. Hindari data pribadi.</p>
<button type="submit">Kirim RSVP</button></form></section>
<section><h2>Doa & ucapan</h2>
<?php foreach ($ucapan as $item): ?>
<article><strong><?= e($item['nama']) ?></strong><p><?= nl2br(e($item['ucapan'])) ?></p></article>
<?php endforeach; ?>
<?php if (!$ucapan): ?><p>Belum ada ucapan. Jadilah yang pertama!</p><?php endif; ?>
</section><footer>Terima kasih atas doa dan kehadiran Anda.</footer>
</main></body></html>
